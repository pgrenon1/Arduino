#ifndef MY_LOG_H
#define MY_LOG_H

#include "TempHu.h"

class Log
{
    private:
        char* dateTime;
        TempHu tempHu;
        TempHu targetTempHu;
    public:
        Log(char* datetime, TempHu tempHu, TempHu targetTempHu);
};

#endif
