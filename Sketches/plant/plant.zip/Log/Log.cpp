#include "Log.h"
#include "TempHu.h"

Log::Log(char* dateTime, TempHu tempHu, TempHu targetTempHu)
{
    this->dateTime = dateTime;
    this->tempHu = tempHu;
    this->targetTempHu = targetTempHu;
}
